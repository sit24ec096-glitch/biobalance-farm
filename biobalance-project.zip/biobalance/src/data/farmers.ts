import { Farm, Ver } from '../types';
import { catOf, incentiveOf } from '../utils/format';
import { REGIONS } from './constants';
const mk = (id: string, place: string, region: string, acres: number, eco: number, bio: number, credits: number, change: number, ver: Ver): Farm => {
  const score = Math.round((eco + bio) / 2);
  return { id, place, region, acres, eco, bio, score, credits, change, ver, incentive: incentiveOf(score, ver), cat: catOf(eco, bio, change) };
};

// Registry sample (10–15 farmers across India)
export const REGISTRY: Farm[] = [
  mk('BB-1025', 'Pune', 'Maharashtra', 4.5, 81, 74, 182, 26, 'Verified'),
  mk('BB-1182', 'Nashik', 'Maharashtra', 3.2, 70, 58, 96, 14, 'Pending'),
  mk('BB-1240', 'Mysuru', 'Karnataka', 6.0, 77, 82, 214, 22, 'Verified'),
  mk('BB-1311', 'Dharwad', 'Karnataka', 2.8, 52, 61, 88, 18, 'Verified'),
  mk('BB-1407', 'Coimbatore', 'Tamil Nadu', 5.1, 84, 79, 201, 19, 'Verified'),
  mk('BB-1466', 'Thanjavur', 'Tamil Nadu', 3.9, 58, 47, 54, 6, 'Verified'),
  mk('BB-1533', 'Ludhiana', 'Punjab', 9.5, 90, 55, 120, 9, 'Verified'),
  mk('BB-1598', 'Amritsar', 'Punjab', 7.4, 72, 63, 110, 12, 'Pending'),
  mk('BB-1640', 'Anand', 'Gujarat', 4.0, 79, 71, 158, 17, 'Verified'),
  mk('BB-1712', 'Indore', 'Madhya Pradesh', 8.2, 68, 66, 143, 15, 'Verified'),
  mk('BB-1789', 'Sagar', 'Madhya Pradesh', 2.5, 46, 52, 61, 11, 'Rejected'),
  mk('BB-1856', 'Lucknow', 'Uttar Pradesh', 3.6, 63, 69, 132, 21, 'Verified'),
  mk('BB-1904', 'Varanasi', 'Uttar Pradesh', 2.2, 49, 44, 40, 5, 'Verified'),
];

// Deterministic pseudo-random scatter points
let seed = 7;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
export const FARMS: Farm[] = [...REGISTRY, ...Array.from({ length: 130 }, (_, i) => {
  const eco = Math.round(35 + rnd() * 60), bio = Math.round(30 + rnd() * 65), ch = Math.round(rnd() * 30 - 2);
  return mk(`BB-${2000 + i}`, REGIONS[i % 7], REGIONS[i % 7], Math.round((2 + rnd() * 8) * 10) / 10, eco, bio, Math.round(bio * 2.2), ch, rnd() > 0.15 ? 'Verified' : 'Pending');
})];
