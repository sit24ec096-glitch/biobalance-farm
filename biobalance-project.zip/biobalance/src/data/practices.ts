import { Ver } from '../types';
export const PRACTICES = [
  { name: 'Crop diversification', pts: 10 }, { name: 'Intercropping', pts: 10 }, { name: 'Flower/pollinator habitat', pts: 8 },
  { name: 'Native vegetation', pts: 15 }, { name: 'Crop rotation', pts: 10 }, { name: 'Water-efficient irrigation', pts: 8 },
  { name: 'Reduced chemical dependency', pts: 10 },
];
export const ROI = [
  { name: 'Flower Strip', cost: 2000, credits: 10, roi: '5' }, { name: 'Native Vegetation', cost: 5000, credits: 15, roi: '3' }, { name: 'Cover Crop', cost: 1500, credits: 8, roi: '5.3' },
];
export const VERIFICATIONS = [
  { farmer: 'BB-1025', practice: 'Pollinator habitat', evidence: 'Photo + location', status: 'Verified' as Ver, credits: 8 },
  { farmer: 'BB-1182', practice: 'Native vegetation', evidence: 'Pending review', status: 'Pending' as Ver, credits: 15 },
  { farmer: 'BB-1240', practice: 'Crop rotation', evidence: 'Field log + photo', status: 'Verified' as Ver, credits: 10 },
  { farmer: 'BB-1598', practice: 'Water-efficient irrigation', evidence: 'Invoice + photo', status: 'Pending' as Ver, credits: 8 },
  { farmer: 'BB-1789', practice: 'Intercropping', evidence: 'Photo unclear', status: 'Rejected' as Ver, credits: 0 },
];
