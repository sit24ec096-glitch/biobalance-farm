import { Cat } from '../types';
export const CATS: Cat[] = ['Balanced', 'Biodiversity improving', 'Economically strong', 'Needs attention'];
export const CAT_COLOR: Record<Cat, string> = { Balanced: '#15803d', 'Biodiversity improving': '#eab308', 'Economically strong': '#2563eb', 'Needs attention': '#dc2626' };
export const REGIONS = ['Maharashtra', 'Karnataka', 'Tamil Nadu', 'Punjab', 'Gujarat', 'Madhya Pradesh', 'Uttar Pradesh'];
export const PERIODS = { 'Current Season': { f: 1, d: 0 }, 'Previous Season': { f: 0.92, d: -3.1 }, 'Year to Date': { f: 1.6, d: -1.2 } } as const;
export type Period = keyof typeof PERIODS;
