import { useMemo, useState } from 'react';
import { Bell, Cloud, Coins, FileText, Landmark, LayoutDashboard, Map, Menu, Search, Settings as Cog, ShieldCheck, Sprout, Users, Wallet, X } from 'lucide-react';
import { Select } from './components/ui';
import FarmerDetail from './components/FarmerDetail';
import { Overview } from './pages/Overview';
import { Farmers } from './pages/Farmers';
import { Credits } from './pages/Credits';
import { Economic } from './pages/Economic';
import { Incentives } from './pages/Incentives';
import { Regional } from './pages/Regional';
import { Verification } from './pages/Verification';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { Farm, PERIODS, Period, REGISTRY, REGIONS, kpis } from './data';

const NAV = [['Overview', LayoutDashboard], ['Farmers', Users], ['Biodiversity', Sprout], ['Economic Performance', Wallet], ['BioBalance Credits', Coins],
  ['Incentives', Landmark], ['Regional Analysis', Map], ['Verification', ShieldCheck], ['Reports', FileText], ['Settings', Cog]] as const;
const STATUSES = ['All', 'Verified', 'Pending', 'Rejected', 'Needs support'];

export default function App() {
  const [page, setPage] = useState('Overview');
  const [period, setPeriod] = useState<Period>('Current Season');
  const [region, setRegion] = useState('All India');
  const [status, setStatus] = useState('All');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [sel, setSel] = useState<Farm | null>(null);

  const okStatus = (f: Farm) => status === 'All' || (status === 'Needs support' ? f.cat === 'Needs attention' : f.ver === status);
  const k = useMemo(() => { const b = kpis(region, period); return { ...b, sub: b.sub.filter(okStatus) }; }, [region, period, status]);
  const registry = useMemo(() => REGISTRY.filter(f => (region === 'All India' || f.region === region) && okStatus(f) &&
    `${f.id} ${f.place} ${f.region}`.toLowerCase().includes(q.trim().toLowerCase())), [region, status, q]);
  const go = (p: string) => { setPage(p); setOpen(false); };

  const body = () => {
    switch (page) {
      case 'Farmers': return <Farmers farms={registry} onOpen={setSel} />;
      case 'Biodiversity': case 'BioBalance Credits': return <Credits />;
      case 'Economic Performance': return <Economic farms={k.sub} registry={registry} />;
      case 'Incentives': return <Incentives onNav={go} />;
      case 'Regional Analysis': return <Regional />;
      case 'Verification': return <Verification />;
      case 'Reports': return <Reports farms={registry} />;
      case 'Settings': return <Settings />;
      default: return <Overview k={k} />;
    }
  };
  return (
    <div className="flex min-h-screen">
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-green-950 p-5 text-green-50 transition-transform lg:static lg:translate-x-0 ${open ? '' : '-translate-x-full'}`}>
        <div className="font-display text-2xl">🏛️ BioBalance</div><div className="text-sm text-green-300">Government Portal</div>
        <p className="mt-2 text-xs text-green-200">Rewarding the balance between farmer livelihoods and nature.</p>
        <nav className="mt-6 flex-1 space-y-1">{NAV.map(([n, Icon]) => (
          <button key={n} onClick={() => go(n)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm ${page === n ? 'bg-green-800' : 'hover:bg-green-900'}`}><Icon size={16} />{n}</button>))}</nav>
        <div className="border-t border-green-800 pt-3 text-sm"><b>Cloud Status</b><div className="flex items-center gap-1 text-xs text-green-300"><Cloud size={12} />🟢 Data synchronized</div></div>
      </aside>
      <main className="min-w-0 flex-1">
        <div className="bg-amber-100 px-4 py-1 text-center text-xs font-semibold text-amber-900">Prototype / Demo Data — fictional farms, credits and incentive amounts. Not an existing government scheme.</div>
        <header className="flex flex-wrap items-center gap-3 p-4 lg:px-8">
          <button className="lg:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
          <div className="min-w-0 flex-1"><p className="text-xs text-green-800">Agricultural Sustainability & Biodiversity Monitoring System</p>
            <h1 className="font-display text-2xl text-green-950">Government Overview</h1><p className="text-sm text-stone-600">Verified information received from participating farms.</p></div>
          <label className="flex items-center gap-2 rounded-lg bg-white px-2 py-1 ring-1 ring-stone-300"><Search size={16} /><input value={q} onChange={e => { setQ(e.target.value); if (page !== 'Farmers') setPage('Farmers'); }} placeholder="Search farmer, place, region" className="w-44 bg-transparent text-sm outline-none" /></label>
          <Bell size={18} /><span className="rounded-full bg-green-800 px-3 py-1 text-sm text-white">Government Admin</span>
        </header>
        <div className="flex flex-wrap items-center gap-4 px-4 pb-4 lg:px-8">
          <Select label="Monitoring Period" value={period} options={Object.keys(PERIODS)} onChange={v => setPeriod(v as Period)} />
          <Select label="Region" value={region} options={['All India', ...REGIONS]} onChange={setRegion} />
          <Select label="Status" value={status} options={STATUSES} onChange={setStatus} />
        </div>
        <div className="px-4 pb-10 lg:px-8">{body()}</div>
        <p className="pb-6 text-center font-display text-lg text-green-900">🌱 Measure sustainability. Recognize effort. Support farmers. Protect biodiversity.</p>
      </main>
      {sel && <FarmerDetail farm={sel} onClose={() => setSel(null)} />}
    </div>
  );
}
