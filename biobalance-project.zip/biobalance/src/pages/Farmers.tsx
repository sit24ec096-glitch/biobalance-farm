import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Farmers({ farms, onOpen }: { farms: Farm[]; onOpen: (f: Farm) => void }) {
  const H = ['Farmer ID', 'Region', 'Farm Size', 'Economic', 'Biodiversity', 'BioBalance', 'Credits', 'Change', 'Verification', 'Incentive Status'];
  return (<Card title="Farmer Sustainability Registry"><div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm">
    <thead><tr className="border-b text-stone-500">{H.map(h => <th key={h} className="py-2 pr-3 font-semibold">{h}</th>)}</tr></thead>
    <tbody>{farms.map(f => (
      <tr key={f.id} tabIndex={0} onKeyDown={e => e.key === 'Enter' && onOpen(f)} onClick={() => onOpen(f)} className="cursor-pointer border-b border-stone-100 hover:bg-green-50">
        <td className="py-2 font-semibold">{f.id}</td><td>{f.place}</td><td>{f.acres} acres</td><td>{f.eco}</td><td>{f.bio}</td><td>{f.score}</td><td>{f.credits}</td>
        <td className="text-green-700">+{f.change}</td><td><Badge tone={verTone(f.ver)}>{f.ver === 'Verified' ? '✓ Verified' : f.ver}</Badge></td><td><Badge tone={incTone(f.incentive)}>{f.incentive}</Badge></td>
      </tr>))}</tbody></table></div><p className="mt-2 text-xs text-stone-500">Select a row to open the farmer detail.</p></Card>);
}
