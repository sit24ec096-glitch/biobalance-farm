import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Credits() {
  return (<div className="space-y-6">
    <Card title="BioBalance Credits">
      <p className="mb-4 text-sm">Credits represent the verified contribution of a farm toward biodiversity-friendly and resource-efficient agriculture.</p>
      {PRACTICES.map(p => <div key={p.name} className="mb-2 grid grid-cols-[1fr_2fr_3rem] items-center gap-3 text-sm"><span>{p.name}</span><ScoreBar value={p.pts * 6} /><b className="text-green-800">+{p.pts}</b></div>)}
      <Disclaimer>Credit values shown are prototype weights for demonstration and would require agricultural/ecological validation before real-world deployment.</Disclaimer>
    </Card>
    <Card title="Biodiversity ROI (Prototype / Demo Data)">
      <p className="mb-3 text-sm">Measures the relative biodiversity benefit obtained for the additional economic resources invested in ecological interventions.</p>
      <div className="grid gap-3 md:grid-cols-3">{ROI.map(r => <div key={r.name} className="rounded-xl bg-green-50 p-4"><div className="font-semibold text-green-900">{r.name}</div>
        <div className="text-sm">Additional cost: {inr(r.cost)}</div><div className="text-sm">Benefit: +{r.credits} credits</div><div className="mt-1 font-display text-lg text-green-800">{r.roi} credits / ₹1,000</div></div>)}</div>
      <Disclaimer>Prototype calculations for demonstration only.</Disclaimer>
    </Card></div>);
}
