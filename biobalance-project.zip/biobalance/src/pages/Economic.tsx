import { Badge, Card, Disclaimer } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { Farm, LIVELIHOOD_GUARD, econ, inr } from '../data';

/** Economic performance: balance chart + Livelihood Guard check per farmer. */
export function Economic({ farms, registry }: { farms: Farm[]; registry: Farm[] }) {
  return (<div className="space-y-6"><Scatterplot farms={farms} />
    <Card title="Livelihood Guard">
      <p className="mb-3 text-sm">Checks whether estimated profit stays above the farmer's minimum acceptable profit ({inr(LIVELIHOOD_GUARD)}, Prototype / Demo Data).</p>
      <div className="overflow-x-auto"><table className="w-full min-w-[520px] text-left text-sm"><thead><tr className="border-b text-stone-500">{['Farmer', 'Estimated profit', 'Guard', 'Status'].map(h => <th key={h} className="py-2">{h}</th>)}</tr></thead>
        <tbody>{registry.map(f => { const p = econ(f.acres).profit; return <tr key={f.id} className="border-b border-stone-100"><td className="py-2 font-semibold">{f.id}</td><td>{inr(p)}</td><td>{inr(LIVELIHOOD_GUARD)}</td><td><Badge tone={p >= LIVELIHOOD_GUARD ? 'green' : 'blue'}>{p >= LIVELIHOOD_GUARD ? 'Above threshold' : 'Needs support'}</Badge></td></tr>; })}</tbody></table></div>
      <Disclaimer>Prototype / Demo Data — fictional figures, not an existing government scheme.</Disclaimer></Card></div>);
}
