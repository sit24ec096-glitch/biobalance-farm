import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
const FLOW = ['Farmer data', 'Economic + biodiversity analysis', 'BioBalance score', 'Verified credits', 'Government insights', 'Targeted support / incentives'];
type K = ReturnType<typeof kpis>;
export function Overview({ k }: { k: K }) {
  const insights = [
    [<Leaf />, 'Biodiversity opportunity', '12% of participating farms have low biodiversity scores but remain economically viable, indicating potential for targeted ecological interventions.'],
    [<Droplets />, 'Resource opportunity', 'Water-efficient practices are associated with improved resource scores in the current prototype dataset.'],
    [<Coins />, 'Credit growth', 'Verified BioBalance Credits increased 14.8% compared with the previous monitoring period.'],
    [<ShieldAlert />, 'Support required', '1,248 farms are currently below their selected livelihood threshold and may require technical or financial support.'],
  ];
  return (<div className="space-y-6">
    <Card><div className="flex flex-wrap items-center gap-1 text-sm font-semibold text-green-900">
      {FLOW.map((s, i) => <span key={s} className="flex items-center gap-1"><span className="rounded-full bg-green-100 px-3 py-1">{s}</span>{i < FLOW.length - 1 && <ChevronRight size={16} className="text-green-600" />}</span>)}
    </div><p className="mt-2 text-xs text-stone-500">Measure → Understand → Support → Improve</p></Card>
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      <Kpi icon={<Wheat size={18} />} label="Participating Farms" value={k.farms.toLocaleString('en-IN')} sub="+8.4% this season" />
      <Kpi icon={<Scale size={18} />} label="Average BioBalance Score" value={`${k.score} / 100`} sub="▲ trending up vs baseline" bar={k.score} />
      <Kpi icon={<Coins size={18} />} label="Verified BioBalance Credits" value={k.credits.toLocaleString('en-IN')} sub="Verified credits · Prototype / Demo Data" />
      <Kpi icon={<Sprout size={18} />} label="Average Biodiversity Score" value={`${k.bio} / 100`} sub="Progress toward 100" bar={k.bio} />
      <Kpi icon={<Wallet size={18} />} label="Economically Viable Farms" value={`${k.viable}%`} sub="Above selected livelihood threshold" />
      <Kpi icon={<CreditCard size={18} />} label="Proposed Incentive Pool" value={`₹${k.pool} Cr`} sub="Prototype estimate · Demo Data" />
    </div>
    <Scatterplot farms={k.sub} />
    <Card title="Government Insights"><div className="grid gap-3 md:grid-cols-2">
      {insights.map(([ic, t, b], i) => <div key={i} className="rounded-xl bg-green-50 p-4"><div className="mb-1 flex items-center gap-2 font-semibold text-green-900">{ic}{t as string}</div><p className="text-sm">{b as string}</p></div>)}
    </div><Disclaimer>Insights are generated from the mock dataset, not real government statistics.</Disclaimer></Card>
  </div>);
}
