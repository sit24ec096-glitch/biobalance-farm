import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Verification() {
  const [f, setF] = useState('All');
  const rows = VERIFICATIONS.filter(v => f === 'All' || v.status === f);
  return (<div className="space-y-6"><Card title="Verification Center">
    <div className="flex flex-wrap items-center gap-1 text-sm">{['Farmer submits evidence', 'Evidence review', 'Practice verification', 'Credits calculated', 'Cloud record updated'].map((s, i) =>
      <span key={s} className="flex items-center gap-1"><span className="rounded-full bg-green-100 px-3 py-1">{s}</span>{i < 4 && <ChevronRight size={14} />}</span>)}</div>
    <div className="my-4 flex gap-2">{['All', 'Verified', 'Pending', 'Rejected'].map(o => <button key={o} onClick={() => setF(o)} className={`rounded-full px-3 py-1 text-sm ${f === o ? 'bg-green-800 text-white' : 'bg-stone-100'}`}>{o}</button>)}</div>
    <div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left text-sm"><thead><tr className="border-b text-stone-500">{['Farmer', 'Practice', 'Evidence', 'Status', 'Credits'].map(h => <th key={h} className="py-2">{h}</th>)}</tr></thead>
      <tbody>{rows.map(v => <tr key={v.farmer + v.practice} className="border-b border-stone-100"><td className="py-2 font-semibold">{v.farmer}</td><td>{v.practice}</td><td>{v.evidence}</td><td><Badge tone={verTone(v.status)}>{v.status === 'Verified' ? '✓ Verified' : v.status === 'Pending' ? '⏳ Pending' : 'Rejected'}</Badge></td><td>+{v.credits}</td></tr>)}</tbody></table></div>
  </Card></div>);
}
