import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Incentives({ onNav }: { onNav: (p: string) => void }) {
  const tiers = [['50–69 BioBalance', 'Basic support'], ['70–84', 'Enhanced support'], ['85–100', 'High-performance support']];
  return (<Card title="Incentive Program">
    <div className="grid gap-3 sm:grid-cols-3">{[['Total eligible farms', '8,426'], ['Potential incentive requirement', '₹18.6 Cr'], ['Average proposed support', '₹22,100']].map(([l, v]) =>
      <div key={l} className="rounded-xl bg-green-50 p-4"><div className="text-xs text-stone-500">{l}</div><div className="font-display text-2xl text-green-900">{v}</div></div>)}</div>
    <div className="mt-4 space-y-2">{tiers.map(([a, b]) => <div key={a} className="flex justify-between rounded-lg bg-stone-50 p-3 text-sm"><span>{a}</span><b>{b}</b></div>)}</div>
    <Disclaimer>Prototype incentive framework — final eligibility and funding rules would be determined by the responsible government authority.</Disclaimer>
    <div className="mt-4 flex flex-wrap gap-2">
      <button className="rounded-lg bg-green-800 px-4 py-2 text-sm text-white" onClick={() => onNav('Farmers')}>Review Eligible Farms</button>
      <button className="rounded-lg border border-green-800 px-4 py-2 text-sm text-green-800" onClick={() => window.print()}>Export Report</button>
      <button className="rounded-lg border border-green-800 px-4 py-2 text-sm text-green-800" onClick={() => onNav('Regional Analysis')}>View Regional Allocation</button>
    </div></Card>);
}
