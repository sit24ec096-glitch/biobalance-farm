import { Card, Disclaimer } from '../components/ui';
import { Farm } from '../data';

/** Exports the currently filtered registry as CSV (local, no network). */
export function Reports({ farms }: { farms: Farm[] }) {
  const csv = () => {
    const rows = [['Farmer ID', 'Region', 'Acres', 'Economic', 'Biodiversity', 'BioBalance', 'Credits', 'Change', 'Verification', 'Incentive'], ...farms.map(f => [f.id, `${f.place} ${f.region}`, f.acres, f.eco, f.bio, f.score, f.credits, f.change, f.ver, f.incentive])];
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([rows.map(r => r.join(',')).join('\n')], { type: 'text/csv' }));
    a.download = 'biobalance-demo-registry.csv'; a.click();
  };
  return (<Card title="Reports"><p className="text-sm">Export the filtered registry ({farms.length} records).</p>
    <div className="mt-3 flex gap-2"><button onClick={csv} className="rounded-lg bg-green-800 px-4 py-2 text-sm text-white">Download CSV</button><button onClick={() => window.print()} className="rounded-lg border border-green-800 px-4 py-2 text-sm text-green-800">Print / Save PDF</button></div>
    <Disclaimer>Prototype / Demo Data — all values are fictional.</Disclaimer></Card>);
}
