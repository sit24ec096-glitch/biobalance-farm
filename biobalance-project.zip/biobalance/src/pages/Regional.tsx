import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Regional() {
  const [key, setKey] = useState<'score' | 'bio' | 'eco' | 'credits' | 'change'>('score');
  const rows = [...REGION_STATS].sort((a, b) => b[key] - a[key]);
  const opts = { score: 'BioBalance', bio: 'Biodiversity', eco: 'Economic viability', credits: 'Credits', change: 'Improvement from baseline' };
  return (<Card title="Regional Analysis">
    <label className="mb-3 flex items-center gap-2 text-sm">Sort by <select className="rounded-lg border px-2 py-1" value={key} onChange={e => setKey(e.target.value as typeof key)}>{Object.entries(opts).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
    <div className="grid gap-3 md:grid-cols-2">{rows.map(r => <div key={r.region} className="rounded-xl bg-green-50 p-4"><div className="font-display text-lg text-green-900">{r.region}</div>
      <div className="mt-1 grid grid-cols-2 gap-x-4 text-sm"><span>Farms: {r.farms.toLocaleString('en-IN')}</span><span>BioBalance: {r.score}</span><span>Biodiversity: {r.bio}</span><span>Economic: {r.eco}</span><span>Avg credits: {r.credits}</span><span>Need: ₹{r.need} Cr</span></div>
      <div className="mt-2"><ScoreBar value={r.score} /></div></div>)}</div></Card>);
}
