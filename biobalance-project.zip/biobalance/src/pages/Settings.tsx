import { useState } from 'react';
import { ChevronRight, Coins, Droplets, Leaf, ShieldAlert, Sprout, Wheat, Scale, Wallet, CreditCard } from 'lucide-react';
import { Badge, Card, Disclaimer, Kpi, ScoreBar, incTone, verTone } from '../components/ui';
import { Scatterplot } from '../components/ScatterCard';
import { CATS, CAT_COLOR, Farm, PRACTICES, REGION_STATS, ROI, VERIFICATIONS, inr, kpis } from '../data';
export function Settings() {
  return (<Card title="Responsible Data Use"><ul className="list-disc space-y-2 pl-5 text-sm">
    {['Farmer data should be collected with appropriate consent.', 'Only necessary information should be shared with authorized government users.', 'Personal information should be protected.', 'Credit calculations should be explainable.', 'Farmers should be able to understand why they received a particular score.', 'The system should support government decisions rather than automatically making decisions about farmers.'].map(t => <li key={t}>{t}</li>)}
  </ul><p className="mt-4 text-sm text-stone-600">Neutral language is used throughout: High improvement, Stable, Needs support, Verification pending, Economically viable, Biodiversity improving.</p></Card>);
}
