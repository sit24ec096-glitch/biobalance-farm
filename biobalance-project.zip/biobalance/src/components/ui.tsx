import { ReactNode } from 'react';
import { X } from 'lucide-react';

export const Card = ({ title, children, className = '' }: { title?: string; children: ReactNode; className?: string }) => (
  <section className={`rounded-2xl bg-white p-5 shadow-sm ring-1 ring-stone-200 ${className}`}>
    {title && <h2 className="mb-3 font-display text-xl text-green-900">{title}</h2>}{children}
  </section>
);
export const ScoreBar = ({ value, color = 'bg-green-700' }: { value: number; color?: string }) => (
  <div className="h-2 w-full rounded-full bg-stone-100"><div className={`h-2 rounded-full ${color}`} style={{ width: `${Math.min(100, value)}%` }} /></div>
);
export const Kpi = ({ icon, label, value, sub, bar }: { icon: ReactNode; label: string; value: string; sub: string; bar?: number }) => (
  <div className="rounded-2xl bg-gradient-to-br from-white to-green-50 p-5 shadow-sm ring-1 ring-green-100">
    <div className="flex items-center gap-2 text-sm text-stone-600"><span className="text-green-800">{icon}</span>{label}</div>
    <div className="mt-2 font-display text-3xl text-green-900">{value}</div>
    {bar !== undefined && <div className="mt-2"><ScoreBar value={bar} /></div>}
    <div className="mt-1 text-xs text-stone-500">{sub}</div>
  </div>
);
const tones = { green: 'bg-green-100 text-green-800', amber: 'bg-amber-100 text-amber-800', blue: 'bg-sky-100 text-sky-800', red: 'bg-rose-100 text-rose-800', gray: 'bg-stone-100 text-stone-700' };
export const Badge = ({ tone, children }: { tone: keyof typeof tones; children: ReactNode }) => (
  <span className={`whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${tones[tone]}`}>{children}</span>
);
export const Disclaimer = ({ children }: { children: ReactNode }) => <p className="mt-3 rounded-lg bg-amber-50 p-2 text-xs text-amber-900">{children}</p>;
export const Modal = ({ onClose, children }: { onClose: () => void; children: ReactNode }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
    <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6" onClick={e => e.stopPropagation()}>
      <button aria-label="Close" className="float-right rounded p-1 hover:bg-stone-100" onClick={onClose}><X size={18} /></button>{children}
    </div>
  </div>
);
export const Select = ({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (v: string) => void }) => (
  <label className="flex items-center gap-2 text-sm text-stone-600">{label}
    <select className="rounded-lg border border-stone-300 bg-white px-2 py-1" value={value} onChange={e => onChange(e.target.value)}>{options.map(o => <option key={o}>{o}</option>)}</select>
  </label>
);
export const verTone = (v: string) => (v === 'Verified' ? 'green' : v === 'Pending' ? 'amber' : 'red') as keyof typeof tones;
export const incTone = (s: string) => (s.includes('pending') ? 'amber' : s.includes('Needs') ? 'blue' : 'green') as keyof typeof tones;
