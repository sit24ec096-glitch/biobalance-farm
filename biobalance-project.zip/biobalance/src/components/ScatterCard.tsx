import { CartesianGrid, Legend, ReferenceArea, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis } from 'recharts';
import { Card } from './ui';
import { CATS, CAT_COLOR, Farm } from '../data';
const Tip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const f: Farm = payload[0].payload;
  return <div className="rounded-lg bg-white p-2 text-xs shadow ring-1 ring-stone-200"><b>{f.id}</b> · {f.region}<br />Economic {f.eco} · Biodiversity {f.bio}<br />BioBalance {f.score} · Credits {f.credits}</div>;
};
export const Scatterplot = ({ farms }: { farms: Farm[] }) => (
  <Card title="Economic Viability vs Biodiversity">
    <ResponsiveContainer width="100%" height={380}>
      <ScatterChart margin={{ top: 10, right: 20, bottom: 25, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" dataKey="eco" domain={[30, 100]} label={{ value: 'Economic Viability Score', position: 'insideBottom', offset: -12 }} />
        <YAxis type="number" dataKey="bio" domain={[25, 100]} label={{ value: 'Biodiversity Score', angle: -90, position: 'insideLeft' }} />
        <ReferenceArea x1={65} x2={100} y1={65} y2={100} fill="#16a34a" fillOpacity={0.1} stroke="#16a34a" strokeDasharray="4 4" label={{ value: 'BioBalance Zone', fill: '#166534', fontSize: 12 }} />
        <Tooltip content={<Tip />} /><Legend verticalAlign="top" />
        {CATS.map(c => <Scatter key={c} name={c} data={farms.filter(f => f.cat === c)} fill={CAT_COLOR[c]} />)}
      </ScatterChart>
    </ResponsiveContainer>
  </Card>
);
