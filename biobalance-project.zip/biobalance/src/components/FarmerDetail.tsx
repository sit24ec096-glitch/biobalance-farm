import { Farm, PRACTICES, inr } from '../data';
import { Badge, Modal, ScoreBar } from './ui';

/** Detail panel for one farmer. Economic figures are derived from farm size (demo model). */
export default function FarmerDetail({ farm, onClose }: { farm: Farm; onClose: () => void }) {
  const rev = Math.round(farm.acres * 31500 / 1000) * 1000, cost = Math.round(farm.acres * 17300 / 1000) * 1000, profit = rev - cost, guard = 60000;
  const adopted = PRACTICES.slice(0, Math.max(2, Math.ceil(farm.bio / 20)));
  const before = farm.score - farm.change;
  return (
    <Modal onClose={onClose}>
      <h3 className="font-display text-2xl text-green-900">Farmer {farm.id}</h3>
      <p className="text-sm text-stone-600">{farm.place}, {farm.region} · {farm.acres} acres</p>
      <h4 className="mt-4 font-semibold">Economic performance</h4>
      <div className="mt-1 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
        {[['Expected revenue', rev], ['Estimated cost', cost], ['Estimated profit', profit], ['Livelihood Guard', guard]].map(([l, v]) => (
          <div key={l as string} className="rounded-lg bg-stone-50 p-2"><div className="text-xs text-stone-500">{l}</div>{inr(v as number)}</div>))}
      </div>
      <div className="mt-2"><Badge tone={profit >= guard ? 'green' : 'blue'}>{profit >= guard ? 'Above threshold' : 'Below threshold – may need support'}</Badge></div>
      <h4 className="mt-4 font-semibold">Biodiversity · {farm.bio}/100 · {farm.credits} credits</h4>
      <ul className="mt-1 grid gap-1 text-sm sm:grid-cols-2">{adopted.map(p => <li key={p.name}>✓ {p.name}</li>)}</ul>
      <h4 className="mt-4 font-semibold">Baseline comparison</h4>
      <div className="mt-2 grid grid-cols-3 items-center gap-2 text-center">
        <div className="rounded-xl bg-stone-100 p-3"><div className="text-xs">Before</div><div className="font-display text-3xl">{before}</div></div>
        <div className="text-2xl text-green-700">→</div>
        <div className="rounded-xl bg-green-100 p-3"><div className="text-xs">After</div><div className="font-display text-3xl text-green-900">{farm.score}</div></div>
      </div>
      <p className="mt-2 text-center font-display text-xl text-green-800">+{farm.change} points</p>
      <ScoreBar value={farm.score} />
      <p className="mt-3 text-xs text-stone-500">Score = average of economic ({farm.eco}) and biodiversity ({farm.bio}) scores. Decisions rest with the reviewing officer.</p>
    </Modal>
  );
}
