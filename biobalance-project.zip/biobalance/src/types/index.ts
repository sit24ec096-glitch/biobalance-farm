export type Cat = 'Balanced' | 'Biodiversity improving' | 'Economically strong' | 'Needs attention';
export type Ver = 'Verified' | 'Pending' | 'Rejected';
export interface Farm { id: string; place: string; region: string; acres: number; eco: number; bio: number; score: number; credits: number; change: number; ver: Ver; incentive: string; cat: Cat; }
