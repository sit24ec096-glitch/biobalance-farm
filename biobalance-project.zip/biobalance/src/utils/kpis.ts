import { FARMS } from '../data/farmers';
import { PERIODS, Period, REGIONS } from '../data/constants';
import { avg } from './format';
/** Aggregates for a set of farms. Headline values are anchored to the brief's figures and shifted by region/period. */
export function kpis(region: string, period: Period) {
  const sub = region === 'All India' ? FARMS : FARMS.filter(f => f.region === region);
  const p = PERIODS[period], share = sub.length / FARMS.length;
  const shift = (k: 'score' | 'bio') => avg(sub.map(f => f[k])) - avg(FARMS.map(f => f[k]));
  return {
    sub, farms: Math.round(12548 * share * (period === 'Previous Season' ? 0.92 : 1)),
    score: +(74.6 + shift('score') + p.d).toFixed(1), bio: Math.round(76 + shift('bio') + p.d),
    credits: Math.round(936420 * share * p.f), viable: +(89.2 + (avg(sub.map(f => f.eco)) - avg(FARMS.map(f => f.eco))) / 4).toFixed(1),
    pool: +(18.6 * share * p.f).toFixed(1),
  };
}
export const REGION_STATS = REGIONS.map(r => {
  const s = FARMS.filter(f => f.region === r), farms = Math.round(12548 * s.length / FARMS.length);
  return { region: r, farms, score: Math.round(avg(s.map(f => f.score))), bio: Math.round(avg(s.map(f => f.bio))), eco: Math.round(avg(s.map(f => f.eco))),
    credits: Math.round(avg(s.map(f => f.credits))), change: Math.round(avg(s.map(f => f.change))), need: +(farms * 0.67 * 22100 / 1e7).toFixed(2) };
});
