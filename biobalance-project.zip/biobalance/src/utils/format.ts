import { Cat, Ver } from '../types';
export const inr = (n: number) => '₹' + n.toLocaleString('en-IN');
export const catOf = (e: number, b: number, ch: number): Cat =>
  e >= 65 && b >= 65 ? 'Balanced' : b < 65 && ch >= 15 ? 'Biodiversity improving' : e >= 65 ? 'Economically strong' : 'Needs attention';
export const incentiveOf = (score: number, ver: Ver) =>
  ver !== 'Verified' ? 'Verification pending' : score >= 85 ? 'High-performance support' : score >= 70 ? 'Enhanced support' : score >= 50 ? 'Basic support' : 'Needs support';

export const avg = (a: number[]) => a.reduce((s, x) => s + x, 0) / (a.length || 1);
/** Demo economics derived from farm size (fictional). */
export const econ = (acres: number) => { const rev = Math.round(acres * 31500 / 1000) * 1000, cost = Math.round(acres * 17300 / 1000) * 1000; return { rev, cost, profit: rev - cost }; };
export const LIVELIHOOD_GUARD = 60000;
