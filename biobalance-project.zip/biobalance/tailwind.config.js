export default { content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: { extend: { fontFamily: { sans: ['"Source Sans 3"','system-ui','sans-serif'], display: ['Fraunces','Georgia','serif'] } } }, plugins: [] };
