import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' uses relative asset paths, so the build works on GitHub Pages
// under any repository name (https://USER.github.io/REPO/) without edits.
export default defineConfig({ base: './', plugins: [react()] });
