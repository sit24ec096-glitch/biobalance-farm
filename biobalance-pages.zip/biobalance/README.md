# BioBalance – Government Portal

Agricultural Sustainability & Biodiversity Monitoring System — a **hackathon prototype**.

> **Prototype / Demo Data.** All farms, scores, BioBalance Credits, financial amounts and incentive values are fictional.
> This is not an existing government scheme or system.

BioBalance balances farmer economic viability, biodiversity, resource efficiency and environmental responsibility.
This portal shows the *verified, summarized* information a government officer would receive through the cloud, to
**measure → understand → support → improve** (not to label farmers as good or bad).

## Features
- Overview KPIs, Economic vs Biodiversity scatter chart, government insights
- Farmer registry with search, filters (period, region, status) and a farmer detail panel
- Economic score with Livelihood Guard, biodiversity score, BioBalance score and credits
- BioBalance Credits by practice and Biodiversity ROI
- Verification status, incentive overview (prototype framework), regional analysis
- CSV export, responsive layout, responsible-data-use notes

## Tech
React 18 · TypeScript · Vite · Tailwind CSS 3 · Recharts · Lucide React. No backend or external APIs; all data is local mock data.

## Run locally
```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # type-check + production build
npm run preview  # serve the production build
```

## Deploy to GitHub Pages
The repo includes `.github/workflows/deploy.yml` and a relative `base` in `vite.config.ts`, so it works under any repo name.
1. Push the project to the `main` branch of a GitHub repository.
2. In the repo go to **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**.
3. Push to `main` (or run the workflow from the **Actions** tab). The site appears at `https://<username>.github.io/<repo>/`.

## Structure
```
src/
  components/   shared UI, scatter chart, farmer detail panel
  pages/        Overview, Farmers, Credits, Economic, Incentives, Regional, Verification, Reports, Settings
  data/         mock farmers, practices, ROI, verification records, constants
  types/        shared TypeScript types
  utils/        formatting, demo economics, KPI aggregation
  App.tsx, main.tsx
```

## Notes and limits
Region/period filters shift headline figures rather than recomputing from a full dataset. Revenue and cost in the
farmer detail are derived from farm size for demonstration. Credit weights need agricultural/ecological validation
before any real-world use.
